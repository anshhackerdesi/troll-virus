import getpass

password = "ansh25"

while True:
    user_input = getpass.getpass("Enter the password to stop the virus: ")

    if user_input == password:
        print("Virus stopped. Phew!")
        break
    else:
        print("Incorrect password. you are still fu*king in bd*m...")
